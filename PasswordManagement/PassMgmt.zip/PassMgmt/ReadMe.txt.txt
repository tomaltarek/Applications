�Tomal Tarek,2019

This is a password management system meant for individual. 

These days, ever person needs to keep handful of passwords, sometimes they write it somewhere in the computer, sometimes in cellphone or somewhere online.  Whichever it is, their passwords are not safe and may end up to other people's hand. 
To keep this in mind, this little proram was developed. You just doubleclick on PasswordManagement and you are good to go. 

